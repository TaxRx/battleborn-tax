import { config } from 'dotenv';

// Load environment variables
config();

// Set test timeout
jest.setTimeout(10000); 