import React, { useState, useEffect } from 'react';
import * as Tabs from '@radix-ui/react-tabs';
import { motion } from 'framer-motion';
import { TaxInfo } from '../types';
import { states } from '../data/states';
import { NumericFormat } from 'react-number-format';
import { useTaxStore } from '../store/taxStore';
import { useUserStore } from '../store/userStore';
import { supabase } from '../lib/supabase';

interface InfoFormProps {
  onSubmit: (data: TaxInfo, year: number) => void;
  initialData?: TaxInfo | null;
}

export default function InfoForm({ onSubmit, initialData }: InfoFormProps) {
  const { saveInitialState } = useTaxStore();
  const { user, fetchUserProfile } = useUserStore();

  const [activeTab, setActiveTab] = useState('profile');
  const [selectedYear] = useState(new Date().getFullYear());
  const [formData, setFormData] = useState<TaxInfo>(initialData || {
    standardDeduction: true,
    customDeduction: 0,
    businessOwner: false,
    fullName: '',
    email: user?.email || '',
    filingStatus: 'single',
    dependents: 0,
    homeAddress: '',
    state: 'CA',
    wagesIncome: 0,
    passiveIncome: 0,
    unearnedIncome: 0,
    capitalGains: 0,
    businessName: undefined,
    entityType: undefined,
    businessAddress: undefined,
    ordinaryK1Income: undefined,
    guaranteedK1Income: undefined,
    householdIncome: undefined,
    deductionLimitReached: false
  });

  // Update form data when initialData changes
  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.fullName) {
      console.error('Validation error: Full name is required');
      alert('Please enter your full name');
      return;
    }

    // Validate at least one income source
    const hasIncome = formData.wagesIncome > 0 || 
                     formData.passiveIncome > 0 || 
                     formData.unearnedIncome > 0 || 
                     formData.capitalGains > 0 ||
                     (formData.businessOwner && (
                       (formData.ordinaryK1Income || 0) > 0 || 
                       (formData.guaranteedK1Income || 0) > 0
                     ));

    if (!hasIncome) {
      console.error('Validation error: No income sources provided');
      alert('Please enter at least one source of income');
      return;
    }

    try {
      if (!user) {
        console.error('User not found in handleSubmit');
        throw new Error('No user found. Please log in again.');
      }

      // Ensure user profile is loaded
      console.log('Fetching user profile...');
      await fetchUserProfile();
      
      if (!user) {
        console.error('Failed to load user profile after fetch');
        throw new Error('Failed to load user profile. Please try again.');
      }

      console.log('Submitting form data:', formData);
      // Call the onSubmit callback with the form data
      onSubmit(formData, selectedYear);
    } catch (error) {
      console.error('Error in handleSubmit:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
          name: error.name
        });
      }
      alert(`Failed to save form data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">{selectedYear} Tax Year Information</h1>
      </div>

      <Tabs.Root value={activeTab} onValueChange={setActiveTab}>
        <Tabs.List className="flex space-x-1 border-b mb-8">
          <Tabs.Trigger
            value="profile"
            className={`px-6 py-3 text-sm font-medium transition-colors
              ${activeTab === 'profile' 
                ? 'border-b-2 border-[#12ab61] text-[#12ab61]' 
                : 'text-gray-600 hover:text-gray-900'}`}
          >
            Profile
          </Tabs.Trigger>
          {formData.businessOwner && (
            <Tabs.Trigger
              value="business"
              className={`px-6 py-3 text-sm font-medium transition-colors
                ${activeTab === 'business' 
                  ? 'border-b-2 border-[#12ab61] text-[#12ab61]' 
                  : 'text-gray-600 hover:text-gray-900'}`}
            >
              Business
            </Tabs.Trigger>
          )}
        </Tabs.List>

        <form onSubmit={handleSubmit}>
          <Tabs.Content value="profile">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm p-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Filing Status <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.filingStatus}
                    onChange={(e) => setFormData(prev => ({ ...prev, filingStatus: e.target.value as any }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    required
                  >
                    <option value="single">Single</option>
                    <option value="married_joint">Married Filing Jointly</option>
                    <option value="married_separate">Married Filing Separately</option>
                    <option value="head_household">Head of Household</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    State <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.state}
                    onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    required
                  >
                    {states.map(state => (
                      <option key={state.code} value={state.code}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Number of Dependents
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.dependents}
                    onChange={(e) => setFormData(prev => ({ ...prev, dependents: parseInt(e.target.value) || 0 }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                  />
                </div>

                <div>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.businessOwner}
                      onChange={(e) => setFormData(prev => ({ ...prev, businessOwner: e.target.checked }))}
                      className="rounded border-gray-300 text-[#12ab61] focus:ring-[#12ab61]"
                    />
                    <span className="text-sm font-medium text-gray-700">I own a business</span>
                  </label>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Income Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Wages/Salary Income
                    </label>
                    <NumericFormat
                      value={formData.wagesIncome}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, wagesIncome: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Passive Income
                    </label>
                    <NumericFormat
                      value={formData.passiveIncome}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, passiveIncome: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Unearned Income
                    </label>
                    <NumericFormat
                      value={formData.unearnedIncome}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, unearnedIncome: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Capital Gains
                    </label>
                    <NumericFormat
                      value={formData.capitalGains}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, capitalGains: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </Tabs.Content>

          {formData.businessOwner && (
            <Tabs.Content value="business">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl shadow-sm p-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Business Name
                    </label>
                    <input
                      type="text"
                      value={formData.businessName}
                      onChange={(e) => setFormData(prev => ({ ...prev, businessName: e.target.value }))}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Entity Type
                    </label>
                    <select
                      value={formData.entityType || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, entityType: e.target.value as 'LLC' | 'S-Corp' | 'C-Corp' | 'Sole Prop' | undefined }))}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    >
                      <option value="">Select Entity Type</option>
                      <option value="LLC">LLC</option>
                      <option value="S-Corp">S-Corporation</option>
                      <option value="C-Corp">C-Corporation</option>
                      <option value="Sole Prop">Sole Proprietorship</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Ordinary K-1 Income
                    </label>
                    <NumericFormat
                      value={formData.ordinaryK1Income}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, ordinaryK1Income: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Guaranteed K-1 Income
                    </label>
                    <NumericFormat
                      value={formData.guaranteedK1Income}
                      onValueChange={(values) => setFormData(prev => ({ ...prev, guaranteedK1Income: values.floatValue || 0 }))}
                      thousandSeparator={true}
                      prefix="$"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#12ab61] focus:ring-[#12ab61]"
                    />
                  </div>
                </div>
              </motion.div>
            </Tabs.Content>
          )}

          <div className="mt-8 flex justify-end">
            <button
              type="submit"
              className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-[#12ab61] hover:bg-[#0f9a57] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#12ab61]"
            >
              Save and Continue
            </button>
          </div>
        </form>
      </Tabs.Root>
    </div>
  );
}