import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '@supabase/supabase-js';
import { PostgrestError } from '@supabase/supabase-js';
import db from '../lib/supabaseClient';

interface UserState {
  user: User | null;
  profile: any | null;
  loading: boolean;
  error: string | null;
  fetchUserProfile: () => Promise<void>;
  updateUserProfile: (updates: any) => Promise<void>;
  updateTaxProfile: (updates: any) => Promise<void>;
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      user: null,
      profile: null,
      loading: false,
      error: null,

      fetchUserProfile: async () => {
        set({ loading: true, error: null });
        try {
          const { data: { user } } = await db.auth.getUser();
          if (!user) {
            set({ user: null, profile: null, loading: false });
            return;
          }

          set({ user });

          // Fetch or create profile
          const { data: profileData, error: profileError } = await db
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();

          if (profileError) {
            if (profileError.code === 'PGRST116') {
              // Profile doesn't exist, create it
              const { data: createData, error: createError } = await db
                .from('profiles')
                .insert({
                  id: user.id,
                  email: user.email,
                  fullName: user.user_metadata?.full_name || '',
                  avatarUrl: user.user_metadata?.avatar_url || '',
                })
                .select()
                .single();

              if (createError) throw createError;
              set({ profile: createData });
            } else {
              throw profileError;
            }
          } else {
            set({ profile: profileData });
          }

          // Try to fetch tax profile if it exists
          const { data: taxProfileData } = await db
            .from('tax_profiles')
            .select('*')
            .eq('userId', user.id)
            .single();

          if (taxProfileData) {
            set((state) => ({
              profile: { ...state.profile, taxProfile: taxProfileData }
            }));
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
          set({ error: errorMessage, loading: false });
        } finally {
          set({ loading: false });
        }
      },

      updateUserProfile: async (updates) => {
        set({ loading: true, error: null });
        try {
          const { data: { user } } = await db.auth.getUser();
          if (!user) throw new Error('No authenticated user');

          const { data: updateData, error: updateError } = await db
            .from('profiles')
            .update(updates)
            .eq('id', user.id)
            .select()
            .single();

          if (updateError) throw updateError;
          set({ profile: updateData });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
          set({ error: errorMessage });
        } finally {
          set({ loading: false });
        }
      },

      updateTaxProfile: async (updates) => {
        set({ loading: true, error: null });
        try {
          const { data: { user } } = await db.auth.getUser();
          if (!user) throw new Error('No authenticated user');

          const { data: taxData, error: taxError } = await db
            .from('tax_profiles')
            .upsert({
              userId: user.id,
              ...updates
            })
            .select()
            .single();

          if (taxError) throw taxError;
          set((state) => ({
            profile: { ...state.profile, taxProfile: taxData }
          }));
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
          set({ error: errorMessage });
        } finally {
          set({ loading: false });
        }
      }
    }),
    {
      name: 'user-storage',
      partialize: (state) => ({ user: state.user })
    }
  )
);