export interface TaxProfile {
    id: string;
    userId: string;
    standardDeduction: boolean;
    customDeduction: number;
    businessOwner: boolean;
    filingStatus: string;
    dependents: number;
    homeAddress?: string;
    homeLatitude?: number;
    homeLongitude?: number;
    state?: string;
    wagesIncome: number;
    passiveIncome: number;
    unearnedIncome: number;
    capitalGains: number;
    businessName?: string;
    entityType?: string;
    businessAddress?: string;
    businessLatitude?: number;
    businessLongitude?: number;
    ordinaryK1Income: number;
    guaranteedK1Income: number;
    createdAt: string;
    updatedAt: string;
}

export interface UserPreferences {
    id: string;
    userId: string;
    theme: string;
    notifications: boolean;
    defaultView: string;
    createdAt: string;
    updatedAt: string;
}

export interface UserProfile {
    id: string;
    email: string;
    fullName: string;
    role: string;
    createdAt: string;
    updatedAt: string;
}

export interface User {
    id: string;
    email: string;
    fullName: string;
    role: string;
    hasCompletedTaxProfile: boolean;
    taxInfo?: TaxProfile;
    preferences?: UserPreferences;
    createdAt: string;
    updatedAt: string;
} 