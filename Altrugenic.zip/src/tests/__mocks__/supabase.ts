import { jest } from '@jest/globals';

export interface MockResponse<T> {
  data: T | null;
  error: Error | null;
}

export interface UserData {
  id: string;
  email: string;
}

export interface ProfileData {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  role: string;
  is_admin: boolean;
  home_address: string | null;
  business_name: string | null;
  business_address: string | null;
  entity_type: string | null;
  filing_status: string | null;
  state: string | null;
  dependents: number;
  created_at: string;
  updated_at: string;
}

export interface MockQuery {
  select: jest.Mock;
  eq: jest.Mock;
  single: jest.Mock;
  delete: jest.Mock;
  insert: jest.Mock;
  update: jest.Mock;
}

export const supabase = {
  auth: {
    signUp: jest.fn(),
    signOut: jest.fn(),
    getUser: jest.fn(),
  },
  from: jest.fn(),
}; 