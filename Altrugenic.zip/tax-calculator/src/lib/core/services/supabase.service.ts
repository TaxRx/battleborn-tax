import { supabase } from '../../supabase';

// Export the single instance
export { supabase };