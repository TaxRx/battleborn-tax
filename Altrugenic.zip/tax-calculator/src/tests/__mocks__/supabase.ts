import { jest } from '@jest/globals';

export interface MockResponse<T> {
  data: T | null;
  error: Error | null;
}

export interface UserData {
  id: string;
  email: string;
}

export interface ProfileData {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  role: string;
  is_admin: boolean;
  home_address: string | null;
  business_name: string | null;
  business_address: string | null;
  entity_type: string | null;
  filing_status: string | null;
  state: string | null;
  dependents: number;
  created_at: string;
  updated_at: string;
}

export interface MockQuery<T> {
  data: T | null;
  error: Error | null;
  select: () => MockQuery<T>;
  eq: (field: string, value: any) => MockQuery<T>;
  single: () => Promise<MockResponse<T>>;
  maybeSingle: () => Promise<MockResponse<T>>;
  order: (field: string, options?: { ascending?: boolean }) => MockQuery<T>;
  limit: (count: number) => MockQuery<T>;
  range: (from: number, to: number) => MockQuery<T>;
}

export const supabase = {
  auth: {
    signInWithPassword: jest.fn(),
    signUp: jest.fn(),
    signOut: jest.fn(),
    getSession: jest.fn(),
    onAuthStateChange: jest.fn(),
  },
  from: jest.fn(() => ({
    select: jest.fn(() => ({
      eq: jest.fn(() => ({
        order: jest.fn()
      }))
    })),
    insert: jest.fn(),
    update: jest.fn(() => ({
      eq: jest.fn()
    })),
    delete: jest.fn(() => ({
      eq: jest.fn()
    })),
    eq: jest.fn(),
    single: jest.fn(),
    maybeSingle: jest.fn(),
    order: jest.fn(),
    limit: jest.fn(),
    range: jest.fn(),
  })),
};

export const testConnection = jest.fn(); 